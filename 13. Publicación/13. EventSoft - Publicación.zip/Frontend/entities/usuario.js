class Usuario{
	constructor(id,nombres,apellidos,correo,contrasenia){
		this.id = id;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.correo = correo;
		this.contrasenia = contrasenia;
	}
}