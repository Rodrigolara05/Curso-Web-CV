class Evento{
	constructor(id,imagenUrl,title,description,time){
		this.id = id;
		this.imagenUrl = imagenUrl;
		this.titulo = title;
		this.descripcion = description;
		this.tiempo = time;
	}
}